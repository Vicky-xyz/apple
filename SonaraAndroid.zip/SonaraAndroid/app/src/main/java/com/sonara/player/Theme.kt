package com.sonara.player

import android.content.Context
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

/** One of the six app themes. Colors come straight from the palette specs. */
class ThemeDef(
    val name: String,
    val short: String,
    val light: Boolean,
    val bg: Color,        // primary background
    val card: Color,      // card / surface
    val accent: Color,    // primary accent
    val accent2: Color,   // secondary accent
    val comp1: Color,     // complementary accent 1
    val comp2: Color,     // complementary accent 2
    val text: Color,      // primary text
)

val THEMES = listOf(
    // ---- soft light ----
    ThemeDef("Pastel Lavender & Cream", "Lavender", true,
        Color(0xFFFAF8FC), Color(0xFFEFEAF5), Color(0xFF9D8CB8), Color(0xFFD4C7E2),
        Color(0xFF8CB8A8), Color(0xFFD9A79C), Color(0xFF2F2938)),
    ThemeDef("Rosewood Clay & Warm Beige", "Rosewood", true,
        Color(0xFFF9F5F2), Color(0xFFEFE6E0), Color(0xFFB8867B), Color(0xFFD9BDB3),
        Color(0xFF8AA399), Color(0xFFCCA476), Color(0xFF382B28)),
    ThemeDef("Buttercream & Warm Oat", "Buttercream", true,
        Color(0xFFFCFBF7), Color(0xFFF3EFE4), Color(0xFFC4A97E), Color(0xFFDFD3BE),
        Color(0xFF969E7E), Color(0xFFC28674), Color(0xFF363128)),
    // ---- dark ----
    ThemeDef("Moody Plum & Charcoal", "Plum", false,
        Color(0xFF19171E), Color(0xFF24212C), Color(0xFF9C7CA5), Color(0xFF594961),
        Color(0xFFC99A9E), Color(0xFF7EA8A4), Color(0xFFECE9F0)),
    ThemeDef("Warm Espresso & Taupe", "Espresso", false,
        Color(0xFF1B1715), Color(0xFF27221F), Color(0xFFB89B84), Color(0xFF6E5B4F),
        Color(0xFFCFA16D), Color(0xFF8A9E86), Color(0xFFEFECE9)),
    ThemeDef("Midnight Teal & Slate", "Teal", false,
        Color(0xFF131B1E), Color(0xFF1D282C), Color(0xFF64979E), Color(0xFF3D5B61),
        Color(0xFFD49488), Color(0xFFC9B98B), Color(0xFFE4ECEE)),
)

const val DEFAULT_THEME = 3

class EqPreset(val name: String, val gains: FloatArray)

val EQ_PRESETS = listOf(
    EqPreset("Flat", floatArrayOf(0f, 0f, 0f, 0f, 0f)),
    EqPreset("Bass boost", floatArrayOf(6f, 4f, 0f, 0f, 0f)),
    EqPreset("Treble boost", floatArrayOf(0f, 0f, 0f, 4f, 6f)),
    EqPreset("Vocal", floatArrayOf(-2f, 0f, 4f, 3f, 0f)),
    EqPreset("Rock", floatArrayOf(5f, 3f, -1f, 3f, 5f)),
    EqPreset("Pop", floatArrayOf(-1f, 3f, 4f, 2f, -1f)),
    EqPreset("Jazz", floatArrayOf(3f, 2f, -2f, 2f, 4f)),
    EqPreset("Hip-hop", floatArrayOf(6f, 4f, 0f, 1f, 3f)),
    EqPreset("Electronic", floatArrayOf(5f, 3f, 0f, 3f, 5f)),
    EqPreset("Classical", floatArrayOf(3f, 2f, 0f, 2f, 3f)),
)

val VIZ_NAMES = listOf("Bars", "Wave", "Dots", "Pulse")
val SORT_NAMES = listOf("Recently added", "Title", "Artist", "Length")

class Palette(
    val light: Boolean,
    val bg: Color,
    val card: Color,
    val panel: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val accent2: Color,
    val comp1: Color,
    val comp2: Color,
    val top: Color,
    val onAccent: Color,
)

fun buildPalette(theme: Int, glass: Int): Palette {
    val t = THEMES[theme.coerceIn(0, THEMES.lastIndex)]
    val a = (0.92f - 0.65f * glass / 100f).coerceIn(0.2f, 0.95f)
    return Palette(
        light = t.light,
        bg = t.bg,
        card = t.card,
        panel = t.card.copy(alpha = a),
        text = t.text,
        muted = t.text.copy(alpha = 0.62f),
        accent = t.accent,
        accent2 = t.accent2,
        comp1 = t.comp1,
        comp2 = t.comp2,
        top = lerp(t.bg, t.accent2, if (t.light) 0.55f else 0.45f),
        onAccent = if (t.light) t.text else t.bg,
    )
}

/** Fades every colour to its new value, so switching theme glides instead of snapping. */
@Composable
fun animatePalette(t: Palette): Palette {
    val spec = tween<Color>(520, easing = FastOutSlowInEasing)
    val bg by animateColorAsState(t.bg, spec, label = "pBg")
    val card by animateColorAsState(t.card, spec, label = "pCard")
    val panel by animateColorAsState(t.panel, spec, label = "pPanel")
    val text by animateColorAsState(t.text, spec, label = "pText")
    val muted by animateColorAsState(t.muted, spec, label = "pMuted")
    val accent by animateColorAsState(t.accent, spec, label = "pAccent")
    val accent2 by animateColorAsState(t.accent2, spec, label = "pAccent2")
    val comp1 by animateColorAsState(t.comp1, spec, label = "pComp1")
    val comp2 by animateColorAsState(t.comp2, spec, label = "pComp2")
    val top by animateColorAsState(t.top, spec, label = "pTop")
    val onAccent by animateColorAsState(t.onAccent, spec, label = "pOn")
    return Palette(t.light, bg, card, panel, text, muted, accent, accent2, comp1, comp2, top, onAccent)
}

class AppSettings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("sonara_settings", Context.MODE_PRIVATE)

    // new key: the old 4-theme setting is ignored so nobody lands on a wrong palette
    var theme by mutableIntStateOf(sp.getInt("palette", DEFAULT_THEME).coerceIn(0, THEMES.lastIndex)); private set
    var visualizer by mutableIntStateOf(sp.getInt("visualizer", 0)); private set
    var eqPreset by mutableIntStateOf(sp.getInt("eq", 0)); private set
    var bass by mutableIntStateOf(sp.getInt("bass", 0)); private set
    var fadeSec by mutableIntStateOf(sp.getInt("fade", 0)); private set
    var sort by mutableIntStateOf(sp.getInt("sort", 0)); private set
    var reactive by mutableIntStateOf(sp.getInt("reactive", 0)); private set
    var minLenSec by mutableIntStateOf(sp.getInt("minlen", 30)); private set
    var vizBars by mutableIntStateOf(sp.getInt("vizbars", 32)); private set
    var vizColor by mutableIntStateOf(sp.getInt("vizcolor", 0)); private set
    var vizSens by mutableIntStateOf(sp.getInt("vizsens", 1)); private set
    var vizHeight by mutableIntStateOf(sp.getInt("vizheight", 1)); private set
    var vizThick by mutableIntStateOf(sp.getInt("vizthick", 1)); private set
    var vizShape by mutableIntStateOf(sp.getInt("vizshape", 0)); private set
    var vizMirror by mutableIntStateOf(sp.getInt("vizmirror", 0)); private set
    var spin by mutableIntStateOf(sp.getInt("spin", 1)); private set
    var folderSep by mutableIntStateOf(sp.getInt("foldersep", 1)); private set
    var glass by mutableIntStateOf(sp.getInt("glass", 25)); private set
    var wallType by mutableIntStateOf(sp.getInt("walltype", 0)); private set
    var wallBlur by mutableIntStateOf(sp.getInt("wallblur", 12)); private set
    var wallDim by mutableIntStateOf(sp.getInt("walldim", 35)); private set

    var shuffle: Boolean = sp.getBoolean("shuffle", false)
    var repeat: Int = sp.getInt("repeat", 0)
    var speed: Float = sp.getFloat("speed", 1f)

    fun update(key: String, v: Int) {
        when (key) {
            "palette" -> theme = v
            "visualizer" -> visualizer = v
            "eq" -> eqPreset = v
            "bass" -> bass = v
            "fade" -> fadeSec = v
            "sort" -> sort = v
            "reactive" -> reactive = v
            "minlen" -> minLenSec = v
            "vizbars" -> vizBars = v
            "vizcolor" -> vizColor = v
            "vizsens" -> vizSens = v
            "vizheight" -> vizHeight = v
            "vizthick" -> vizThick = v
            "vizshape" -> vizShape = v
            "vizmirror" -> vizMirror = v
            "spin" -> spin = v
            "foldersep" -> folderSep = v
            "glass" -> glass = v
            "walltype" -> wallType = v
            "wallblur" -> wallBlur = v
            "walldim" -> wallDim = v
        }
        sp.edit().putInt(key, v).apply()
    }

    fun savePlayback(shuffle: Boolean, repeat: Int, speed: Float) {
        this.shuffle = shuffle
        this.repeat = repeat
        this.speed = speed
        sp.edit().putBoolean("shuffle", shuffle).putInt("repeat", repeat).putFloat("speed", speed).apply()
    }
}
